#Calling up the libraries
library(tidyverse)
library(ggplot2)
library(writexl)
library(csvread)
library(dplyr)
library(ggplot2)


#Installing and calling up a package for time series
install.packages("tseries")
install.packages("forecast")

library(tseries)

# Importing the Dataset
credits_data <- read.csv("C:/Users/Family/Desktop/UCU/Big Data Analytics with R/Assignment 1/ida_credits_to_uganda_01-11-2024.csv")

#check a preview of the data
head(credits_data)

#View the dataset
View(credits_data)    #this will open the dataset in a new tab and make it easy to analyze

#setting the working directory
setwd("C:/Users/Family/Desktop/UCU/Big Data Analytics with R/Assignment 1")

#getting the working directory
getwd()

#summary of statistics of the dataset
summary(credits_data)   #this gives us an insight into the type of characters in the dataset, its mean, quartile ranges, among others.

# checking for missing values within the dataset
missing_values <- sapply(credits_data, function(x) sum(is.na(x)))  #this method checks for the sum of missing values within each column
missing_values
#After running it, I noticed that one of the columns had a total of 2 missing values

#Therefore, I'll choose an imputation method(mean) to handle the 2 missing values

#I tried the above method but the missing values persisted, so i have resorted to delete them instead

##Dropping
new_data = na.omit(credits_data)

# Verify if there are still missing values
sum(is.na(credits_data$Service.Charge.Rate))



#Number 1
#Run a time-series analysis on that explains the trend of World Bank fund disbursement to Uganda (hint: use the variable "Disbursed Amount (US$)" [10 Marks]

#since the 'tseries' and 'forecast' packages have failed to install on my version, I will apply a different approach

# make sure that the date column is recognized as a date
new_data$Effective.Date..Most.Recent. <- as.Date(new_data$Effective.Date..Most.Recent., format = "%Y-%m-%d")

# Check if there are unique dates
if (length(unique(new_data$Effective.Date..Most.Recent.)) == 1) {
  stop("Error: The date column contains only one unique value. Check your data.")
}

# Order data by date (if not already sorted)
new_data <- new_data[order(new_data$Effective.Date..Most.Recent.), ]

# Check for missing dates
sum(is.na(new_data$Effective.Date..Most.Recent.))
new_data <- new_data[!is.na(new_data$Effective.Date..Most.Recent.), ]

# Check for date range
print(range(new_data$Effective.Date..Most.Recent.))

# Check if the column is in Date format
str(new_data$Effective.Date..Most.Recent.)  # Should show "Date" as the class

# Confirm the range of the date column
print(range(new_data$Effective.Date..Most.Recent., na.rm=TRUE))



# Check the data type of the column
str(new_data$Disbursed.Amount.Million)


# Scale the Disbursed.Amount (divide by 1,000,000)
new_data$Disbursed.Amount.Million <- new_data$Disbursed.Amount..US.. / 1e6  #this was done in order to make the y-axis label look neat

#extracting the time series data
ts_data <- ts(new_data$Disbursed.Amount.Million, start=c(as.numeric(format(min(new_data$Effective.Date..Most.Recent.), "%Y")),
                                                       as.numeric(format(min(new_data$Effective.Date..Most.Recent.), "%m"))),
              frequency = 12)


# Check the minimum date directly
min_date <- min(new_data$Effective.Date..Most.Recent., na.rm=TRUE)
print(min_date)

max_date <- max(new_data$Effective.Date..Most.Recent., na.rm=TRUE)
print(max_date)

#Plotting the time series data
plot(ts_data, main="Disbursed Amount Over Time", ylab="Disbursed Amount (in millions)", xlab="Year")

#for some reason, the graph doesn't go till 2024 which is the latest date in that column







#Number 2
#Describe the overall "Credit Status" of Uganda based on the provided dataset. [10 Marks]

print(new_data$Credit.Status)  #this is to check for the categorical values in that column

#In order to properly understand the credit status, I'm going with making a bar chart
#I believe that this will help me properly understand the distribution

#Checking and handing missing values in the Credit Status column
str(new_data$Credit.Status)

sum(is.na(new_data$Credit.Status))



#First, we calculate the percentages
credit_status_counts <- new_data %>%
  count(Credit.Status) %>%
  mutate(Percentage = n / sum(n) * 100)

# Sort the data in descending order
credit_status_counts <- credit_status_counts %>%
  arrange(desc(n))

# Create the bar graph with different colors and a legend, removing y-axis labels and ticks
ggplot(credit_status_counts, aes(x = reorder(Credit.Status, -n), y = n)) +
  geom_bar(stat = "identity", fill = "brown") +
  geom_text(aes(label = paste0(round(Percentage, 1), "%")), vjust = -0.5) +
  labs(title = "Credit Status Distribution", x = "Credit Status", y = "Count") +
  theme_minimal() +
  scale_y_continuous(expand = expansion(mult = c(0, 0.1)))




#Number 3
#3.	Explain the "Original principal amount" Uganda borrowed from the World Bank, what patterns can you deduce from it? [10 MARKS]

# make sure that the date column is recognized as a date
new_data$Board.Approval.Date <- as.Date(new_data$Board.Approval.Date, format = "%Y-%m-%d")

# Check if there are unique dates
if (length(unique(new_data$Board.Approval.Date)) == 1) {
  stop("Error: The date column contains only one unique value. Check your data.")
}

# Order data by date (if not already sorted)
new_data <- new_data[order(new_data$Board.Approval.Date), ]

# Check for missing dates
sum(is.na(new_data$Board.Approval.Date))
new_data <- new_data[!is.na(new_data$Board.Approval.Date), ]


# Check if the column is in Date format
str(new_data$Board.Approval.Date)  # Should show "Date" as the class

# Confirm the range of the date column
print(range(new_data$Board.Approval.Date, na.rm=TRUE))

# Scale the Original Principal amount (divide by 1,000,000)
new_data$Original.Prinicipal.Million <- new_data$Original.Principal.Amount..US.. / 1e6



ggplot(new_data, aes(x = Board.Approval.Date, y = Original.Prinicipal.Million)) +
  geom_line(color = "darkorange") +
  labs(title = "Original Principal Amount Approved by the World Bank to Uganda", 
       x = "Year", 
       y = "Amount in Millions of $") +
  theme_minimal()

meanAmount = mean(new_data$Original.Principal.Amount..US..)
print(meanAmount)

# Find the minimum and maximum values and their corresponding dates
maximumPrincipal = max(new_data$Original.Principal.Amount..US..)
print(maximumPrincipal/1e6)

# Extract the date corresponding to the maximum principal value
max_index <- which.max(new_data$Original.Principal.Amount..US..)
maxDate <- new_data$Board.Approval.Date[max_index]

# Print the date
print(maxDate)

minimumPrincipal = min(new_data$Original.Principal.Amount..US..)
print(minimumPrincipal)

# Extract the date corresponding to the maximum principal value
min_index <- which.min(new_data$Original.Principal.Amount..US..)
minDate <- new_data$Board.Approval.Date[min_index]

# Print the date
print(minDate)

